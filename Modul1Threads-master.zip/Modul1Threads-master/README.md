# Modul1Threads

This code is part of the [week on threads](https://datsoftlyngby.github.io/dat2sem2018Fall/Modul1/Threads) second semester.
